class DailyContent {
  final String quote;
  final String author;
  final String songTitle;
  final String artist;
  final String songUrl;

  DailyContent({
    required this.quote,
    required this.author,
    required this.songTitle,
    required this.artist,
    required this.songUrl,
  });
}