import 'package:flutter/material.dart';
import 'home_page.dart';

void main() => runApp(DailyVibeApp());

class DailyVibeApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Daily Vibe',
      theme: ThemeData(
        fontFamily: 'Raleway',
        brightness: Brightness.light,
        primarySwatch: Colors.orange,
      ),
      home: HomePage(),
    );
  }
}