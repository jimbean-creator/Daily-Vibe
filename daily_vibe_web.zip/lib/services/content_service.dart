import '../models/daily_content.dart';

class ContentService {
  static DailyContent getTodayContent() {
    return DailyContent(
      quote: "The future belongs to those who believe in the beauty of their dreams.",
      author: "Eleanor Roosevelt",
      songTitle: "Sun Is Shining",
      artist: "Bob Marley",
      songUrl: "https://open.spotify.com/track/5T8EDUDqKcs6OSOwEsfqG7",
    );
  }
}