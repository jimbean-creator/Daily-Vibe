import 'package:flutter/material.dart';
import 'models/daily_content.dart';
import 'services/content_service.dart';
import 'utils/url_utils.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late DailyContent dailyContent;

  @override
  void initState() {
    super.initState();
    dailyContent = ContentService.getTodayContent();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Daily Vibe')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(dailyContent.quote, style: TextStyle(fontSize: 24, fontStyle: FontStyle.italic), textAlign: TextAlign.center),
            SizedBox(height: 10),
            Text('- ${dailyContent.author}', style: TextStyle(fontSize: 16)),
            SizedBox(height: 30),
            Text('Now Playing: ${dailyContent.songTitle}', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Text('by ${dailyContent.artist}', style: TextStyle(fontSize: 16)),
            ElevatedButton(
              onPressed: () => UrlUtils.launchUrl(dailyContent.songUrl),
              child: Text('Listen on Spotify'),
            )
          ],
        ),
      ),
    );
  }
}